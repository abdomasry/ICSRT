import React, { useEffect, useState } from 'react';
import { PieChart, Pie, Cell, LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import './index.css';

const API = 'http://localhost:3000/api';
const COLORS = ['#8884d8', '#82ca9d', '#ffc658', '#ff8042', '#00C49F', '#FFBB28'];

export default function App() {
  const [stats, setStats] = useState({});
  const [registrationByCountry, setRegistrationByCountry] = useState([]);
  const [registrationTrend, setRegistrationTrend] = useState([]);

  useEffect(() => {
    const fetchStats = async () => {
      const endpoints = ['conferences', 'speakers', 'papers', 'journals', 'registrations', 'contacts'];
      const data = {};

      await Promise.all(endpoints.map(async (e) => {
        const res = await fetch(`${API}/${e}`);
        const json = await res.json();
        data[e] = json.length;

        if (e === 'registrations') {
          const byCountry = {};
          const byDate = {};
          json.forEach(r => {
            if (r.country) {
              byCountry[r.country] = (byCountry[r.country] || 0) + 1;
            }
            const d = new Date(r.registeredAt).toISOString().split('T')[0];
            byDate[d] = (byDate[d] || 0) + 1;
          });

          setRegistrationByCountry(Object.entries(byCountry).map(([name, value]) => ({ name, value })));
          setRegistrationTrend(Object.entries(byDate).map(([date, count]) => ({ date, count })));
        }
      }));

      setStats(data);
    };

    fetchStats();
  }, []);

  return (
    <div className="flex min-h-screen bg-gray-100">
      <aside className="w-64 bg-white shadow-md">
        <div className="text-xl font-bold p-6 border-b">ICSRT</div>
        <nav className="p-4 space-y-2">
          {['Dashboard', 'Conferences', 'Speakers', 'Papers', 'Journals', 'Registrations', 'Contacts'].map((item, idx) => (
            <div key={idx} className="text-gray-700 hover:text-blue-500 cursor-pointer">{item}</div>
          ))}
        </nav>
      </aside>
      <main className="flex-1 p-6">
        <h1 className="text-2xl font-semibold mb-4">Dashboard Overview</h1>
        <div className="grid grid-cols-2 md:grid-cols-3 gap-4 mb-8">
          {Object.entries(stats).map(([key, val], idx) => (
            <div key={idx} className="bg-white shadow rounded p-4">
              <div className="text-sm text-gray-500 capitalize">{key}</div>
              <div className="text-2xl font-bold">{val}</div>
            </div>
          ))}
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <div className="bg-white p-4 rounded shadow">
            <h2 className="text-lg font-semibold mb-2">Registration Trend</h2>
            <ResponsiveContainer width="100%" height={300}>
              <LineChart data={registrationTrend}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="date" />
                <YAxis />
                <Tooltip />
                <Legend />
                <Line type="monotone" dataKey="count" stroke="#8884d8" activeDot={{ r: 8 }} />
              </LineChart>
            </ResponsiveContainer>
          </div>

          <div className="bg-white p-4 rounded shadow">
            <h2 className="text-lg font-semibold mb-2">Participation by Country</h2>
            <ResponsiveContainer width="100%" height={300}>
              <PieChart>
                <Pie data={registrationByCountry} dataKey="value" nameKey="name" cx="50%" cy="50%" outerRadius={100} fill="#8884d8" label>
                  {registrationByCountry.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
          </div>
        </div>
      </main>
    </div>
  );
}
